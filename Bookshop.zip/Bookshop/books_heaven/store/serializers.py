from rest_framework import serializers
from .models import Book, Review, Order, Purchase

class ReviewSerializer(serializers.ModelSerializer):
    user = serializers.CharField(source='user.username')  # Display username instead of user ID

    class Meta:
        model = Review
        fields = ['id', 'user', 'review_text', 'rating', 'created_at']

class BookSerializer(serializers.ModelSerializer):
    reviews = ReviewSerializer(many=True, read_only=True)  # Nested reviews
    image = serializers.ImageField(use_url=True)  # Return image URL

    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'description', 'published_date', 'price', 'image', 'reviews', 'quantity']

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'

class PurchaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Purchase
        fields = ['id', 'name', 'email', 'book', 'quantity', 'address']        

