from django.shortcuts import render
from rest_framework import generics, viewsets, permissions, status
from rest_framework.response import Response
from .models import Book, Order, Purchase
from .serializers import BookSerializer, OrderSerializer, PurchaseSerializer
from django.core.exceptions import ValidationError

# View for rendering the home page
def home(request):
    return render(request, 'store/index.html')

# View for rendering the bookshelf page
def bookshelf(request):
    return render(request, 'store/index2.html')

def orders_view(request):
    return render(request, 'store/orders.html')

def about(request):
    return render(request,'store/about.html')

def contact(request):
    return render(request,'store/contact.html')

def purchase(request):
    return render(request,'store/purchase.html')

# Custom permission to check if the user is a superuser
class IsSuperUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_superuser

# BookDetail view for retrieving a single book
class BookDetail(generics.RetrieveAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

# BookViewSet for handling book operations (CRUD operations for books)
class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

    # Restrict book creation and modification to superusers only
    def create(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            return Response({"error": "Only superusers can add books."}, status=403)
        return super().create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            return Response({"error": "Only superusers can edit books."}, status=403)
        return super().update(request, *args, **kwargs)

    def partial_update(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            return Response({"error": "Only superusers can edit books."}, status=403)
        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        if not request.user.is_superuser:
            return Response({"error": "Only superusers can delete books."}, status=403)
        return super().destroy(request, *args, **kwargs)

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

    def perform_create(self, serializer):
        try:
            serializer.save()
        except ValidationError as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
class PurchaseCreateView(viewsets.ModelViewSet):
    queryset = Purchase.objects.all()
    serializer_class = PurchaseSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)        
