from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField()
    published_date = models.DateField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.ImageField(upload_to='book_images/', null=True, blank=True)  # Book cover image
    quantity = models.PositiveIntegerField(default=0)  # Changed to PositiveIntegerField for quantities

    def __str__(self):
        return self.title

class Review(models.Model):
    book = models.ForeignKey(Book, related_name='reviews', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    review_text = models.TextField()
    rating = models.PositiveIntegerField(default=1, choices=[(i, str(i)) for i in range(1, 6)])  # Ratings between 1 and 5
    created_at = models.DateTimeField(auto_now_add=True)  # Automatically set the review creation time
    
    def __str__(self):
        return f"{self.user.username} - {self.book.title}"

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    date_ordered = models.DateTimeField(auto_now_add=True)
    quantity = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.book.title}"
    
 
class Purchase(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    book = models.CharField(max_length=255)  # You may want to use a ForeignKey if you have a Book model
    quantity = models.PositiveIntegerField()
    address = models.TextField()

    def __str__(self):
        return f"{self.name} - {self.book}"   

    
