from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django.conf.urls.static import static
from django.conf import settings
from .views import BookViewSet, home, bookshelf, OrderViewSet, about, contact, PurchaseCreateView,purchase

# Create a router and register the BookViewSet
router = DefaultRouter()
router.register(r'books', BookViewSet)
router.register(r'orders', OrderViewSet)
router.register(r'purchase',PurchaseCreateView)

urlpatterns = [
    path('', home, name='home'),  # Homepage route
    path('api/', include(router.urls)),  # Include the router URLs under a specific path
    path('bookshelf/', bookshelf, name='bookshelf'),  # Bookshelf router
    path('about/', about, name='about'),
    path('contact/', contact, name='contact'),
    path('purchase/', purchase, name='purchase')
    
    
] 
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)